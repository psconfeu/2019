#!/bin/sh
echo Hello from $(hostname)!
echo the param parameter is: $PT_param