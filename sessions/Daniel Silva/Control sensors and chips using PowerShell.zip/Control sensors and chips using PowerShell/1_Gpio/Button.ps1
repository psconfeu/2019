Import-Module Microsoft.PowerShell.IoT
<#

#>
$buttonPin = 26 #12 on board
$ledPin = 27 #16 on board (upper side of the led)
#region 1- Simple button example

# while($true)
# {
# 	if((Get-GpioPin -Id $buttonPin -PullMode PullUp).Value -eq 'Low')
# 	{
# 		Write-Host "You pressed the button"
# 		Start-Sleep -Milliseconds 100 #Apply a debouncer
# 	}
# }
# #endregion

# #region 2- Button with Led
# while($true)
# {
# 	if((Get-GpioPin -Id $buttonPin -PullMode PullUp).Value -eq 'Low')
# 	{
# 		Set-GpioPin -Id $ledPin -Value High
# 		Start-Sleep -Milliseconds 100 #Apply a debouncer
# 	}
# 	Set-GpioPin -Id $ledPin -Value Low
# }
# #endregion

# #region 3- Button with a way cooler Led(s)
Import-Module /home/pi/Documents/Presentation/2_ws281x_Leds/publish/ws281xPowerShell.dll
$LedStripSettings = [PSCustomObject]@{
	NumberOfLeds = 30
	Brightness = 150
	Color = [System.Drawing.Color]::Green
	Speed = "Fast"
}

while($true)
{
	while((Get-GpioPin -Id $buttonPin -PullMode PullUp).Value -eq 'High')
	{

	}
	$held = 0
	while((Get-GpioPin -Id $buttonPin -PullMode PullUp).Value -eq 'Low' -AND $held -lt 10) #lt 10 because each time $held is incremented, 100ms have passed, after 10 iterations, 1 second passed
	{
		Start-Sleep -Milliseconds 100
		++$held
	}

	if($held -lt 10) #realeased before 1s
	{
		$LedStripSettings | Set-LedAccrossStrip
	}
	else # it was pressed at least during 1 second ( might still be being pressed)
	{
		Write-Host "Button pressed for at least 1 second. "
		Set-RainbowCycle -NumberOfLeds $LedStripSettings.NumberOfLeds -Brightness $LedStripSettings.Brightness -NumberOfCycles 1
		Start-Sleep -Milliseconds 200
	}
}
#endregion