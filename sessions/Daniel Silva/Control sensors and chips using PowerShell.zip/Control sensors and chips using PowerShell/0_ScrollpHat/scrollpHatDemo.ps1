Import-Module ./ScrollpHat.psm1
#region Get commands
    Get-Command -Module ScrollpHat
#endregion

#region simple example
Write-PhatChar "A"

Set-PhatBrightness High
Set-phatBrightness Lowest
#endregion

#region Let's write some text

#Let's have fun with the UniversalDashboard
/home/pi/Documents/Presentation/4_UniversalDashboard/complexDashboard.ps1 
#endregion
