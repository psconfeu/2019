Import-Module UniversalDashboard.Community
function AddJsonResponseToFile {
    param (
        [string]$basePath,
        [string]$newTemperature
    )
    <#Each day has a file, which is given by the date #>
    $fileName = "$((Get-Date).ToString('yyyy_MM_dd')).json"
    $fileFullPath = "$basePath$fileName"
    if((Test-Path $fileFullPath) -eq $false){
        New-Item $basePath -name $fileName -ItemType 'file' -Value '[]' | Out-Null
    }
    $tempPsObj = Get-Content -Path $fileFullPath | ConvertFrom-Json

    $tempPsObj += (ConvertFrom-Json -InputObject $newTemperature)

    Set-Content -Path $fileFullPath -Value (ConvertTo-Json $tempPsObj)
}

$TemperatureEndpoint = New-UDEndpoint -Url "/temperature" -Method "POST" -Endpoint {
    param($Body)
    $basePath = "/home/pi/Documents/Presentation/4_UniversalDashboard/Data/temperature/"
    AddJsonResponseToFile $basePath $Body
    return;
}

$HumidityEndpoint = New-UDEndpoint -Url "/humidity" -Method "POST" -Endpoint {
    param($Body)
    $basePath = "/home/pi/Documents/Presentation/4_UniversalDashboard/Data/humidity/"
    AddJsonResponseToFile $basePath $Body
    return;
}

$ep = New-UDEndpointInitialization -Function "AddJsonResponseToFile"

Start-UDRestApi -Port 10000 -Name MyServer -Endpoint @(
   $TemperatureEndpoint,
   $HumidityEndpoint
) -EndpointInitialization $ep -Wait

# Invoke-RestMethod -Uri http://localhost:10000/api/temperature -Method POST -Body (@{Temperature = "20"; Date = $(Get-Date).ToString("yyyy/MM/dd HH:mm:ss") } | ConvertTo-Json)

