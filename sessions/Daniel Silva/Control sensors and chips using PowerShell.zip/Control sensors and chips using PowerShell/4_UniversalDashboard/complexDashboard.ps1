#Import-Module UniversalDashboard.Community
#region "custom" imports
[System.Reflection.Assembly]::LoadFrom("/home/pi/Documents/Presentation/3_SenseHat/publish/SenseHatPowerShell.dll") | Out-Null
#endregion

$temperatureBasePath = "/home/pi/Documents/Presentation/4_UniversalDashboard/Data/temperature/"
$humidityBasePath    = "/home/pi/Documents/Presentation/4_UniversalDashboard/Data/humidity/"
$senseHat = [SenseHatPowerShell.CoreDeviceFactory]::InitAndGetIt()

$endpointInitializationSplat = @{
	Variable = @("temperatureBasePath", "humidityBasePath, numberOfDays, senseHat")
	Module = @("/home/pi/Documents/Presentation/0_ScrollpHat/ScrollpHat.psm1", "/home/pi/Documents/Presentation/2_ws281x_Leds/publish/ws281xPowerShell.dll")
}
$ep = New-UDEndpointInitialization @endpointInitializationSplat

$pages = @()


$pages += New-UDPage -Name "Leds" -Icon lightbulb_o -Content {
	New-UDRow -Columns {
		New-UDColumn -SmallSize 6 -MediumSize 6 -LargeSize 6 -Content {
			#New-UDCard -Title "Simulate Explosion" -Content {
				New-UDInput -Title "Explosion config" -Content {
					[string[]]$colors = [System.Drawing.Color].GetProperties([Reflection.BindingFlags]'Static,DeclaredOnly,Public') | Select-Object -ExpandProperty Name
					New-UDInputField -Type 'textbox' -Name 'NumberOfLeds' -Placeholder 'How many leds'
					New-UDInputField -Type 'textbox' -Name 'Brightness' -Placeholder 'From 0 to 255' -DefaultValue 10
					New-UDInputField -Type 'select' -Name 'LeftSideColor' -Placeholder 'Choose a color' -Values $colors -DefaultValue "Blue"
					New-UDInputField -Type 'select' -Name 'RightSideColor' -Placeholder 'Choose a color' -Values $colors -DefaultValue "Blue"
					New-UDInputField -Type 'select' -Name 'Speed' -Placeholder @("Slow", "Medium", "Fast") -Values @("Slow", "Medium", "Fast") -DefaultValue "Slow"
				} -Endpoint {
					param([ValidateRange(1,30)][int]$NumberOfLeds, [ValidateRange(0,255)][int]$Brightness, $LeftSideColor, $RightSideColor, $Speed)

					$leftColor = [System.Drawing.Color]::FromName($LeftSideColor)
					$rightColor = [System.Drawing.Color]::FromName($RightSideColor)
					Show-UDToast "Number of leds = $NumberOfLeds, Brightness = $Brightness, leftColor = $LeftColor, rightColor = $rightColor, speed = $Speed"
					$explosionSettings = [PSCustomObject]@{
						NumberOfLeds = $NumberOfLeds
						Brightness = $Brightness
						LeftSideColor = $leftColor
						RightSideColor = $rightColor
						Speed = $Speed
					}
					$explosionSettings | Set-Explosion
				}
			#}
		}
		New-UDColumn -SmallSize 6 -MediumSize 6 -LargeSize 6 -Content {
			#New-UDCard -Text "Led accross the stripe" -Content {
				New-UDInput -Title "Led accross the stripe" -Content {
					[string[]]$colors = [System.Drawing.Color].GetProperties([Reflection.BindingFlags]'Static,DeclaredOnly,Public') | Select-Object -ExpandProperty Name
					New-UDInputField -Type 'textbox' -Name 'NumberOfLeds' -Placeholder 'How many leds'
					New-UDInputField -Type 'textbox' -Name 'Brightness' -Placeholder 'From 0 to 255' -DefaultValue 10
					New-UDInputField -Type 'select' -Name 'Color' -Placeholder 'Choose a color' -Values $colors -DefaultValue "Blue"
					New-UDInputField -Type 'select' -Name 'Speed' -Placeholder @("Slow", "Medium", "Fast") -Values @("Slow", "Medium", "Fast") -DefaultValue "Slow"
				} -Endpoint {
					param([ValidateRange(1,30)][int]$NumberOfLeds, [ValidateRange(0,255)][int]$Brightness, $Color, $Speed)

					$selectedColor = [System.Drawing.Color]::FromName($Color)
					$settings = [PSCustomObject]@{
						NumberOfLeds = $NumberOfLeds
						Brightness = $Brightness
						Color = $selectedColor
						Speed = $Speed
					}
					$settings | Set-LedAccrossStrip
				}
			#}
		}
	}
}


$pages += New-UDPage -Name "Sensors" -Icon thermometer_three_quarters -Content {
    New-UDRow -Columns {
        New-UDColumn -SmallSize 2 -MediumSize 2 -LargeSize 2 -Content {
            #New-UDElement -Id "digital" -Tag "rand"
            New-UDCard -Content {
				New-UDElement -Id "digital" -Tag "rand"
            } -Watermark clock_o -TextSize Medium
        }
        New-UDColumn -Endpoint {
            while ($true) {
				Set-UDElement -Id "digital" -Broadcast -Content { (Get-Date).ToLongTimeString() }
                Start-Sleep -Seconds 1
            }
		}

	}
    New-UDRow -Columns {
        New-UDColumn -Id "TemperatureColumn" -SmallSize 12 -MediumSize 12 -LargeSize 6 -Content {
            New-UDCard -Title "Temperature" -Content {
                New-UDTabContainer -Tabs {
                    New-UDTab -Text "Today" -Content {
                        New-UDChart -Title "" -Type Line -Endpoint {
                            $fileName = "$($((Get-Date)).ToString('yyyy_MM_dd')).json"
                            $fileFullPath = "$temperatureBasePath$fileName"
                            $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue 
                            $obj += $content | ConvertFrom-Json                         
                            $obj | Select-Object Temperature,
                            @{
                                name       = 'Date';
                                expression = { [DateTime]::Parse($_.Date).ToString('HH:mm') }
                            } `
                            | Sort-Object -Property Date `
                            | Out-UDChartData -LabelProperty "Date" -DataProperty "Temperature" -DatasetLabel "Temperature"
                        } -AutoRefresh -RefreshInterval 60 -Options @{
                            scales = @{
                                yAxes = @(
                                    @{
                                        ticks = @{
                                            min = 0
                                            max = 40
                                        }
                                    }
                                )
                            }
                        }
                    }
                    New-UDTab -Text "Yesterday" -Content {
                        New-UDChart -Title "" -Type Line -Endpoint {
                            $fileName = "$($((Get-Date).AddDays(-1)).ToString('yyyy_MM_dd')).json"
                            $fileFullPath = "$temperatureBasePath$fileName"
                            $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue
                            $obj += $content | ConvertFrom-Json
                            $obj | Select-Object Temperature,
                            @{
                                name       = 'Date';
                                expression = { [DateTime]::Parse($_.Date).ToString('HH:mm') }
                            } `
                            | Sort-Object -Property Date `
                            | Out-UDChartData -LabelProperty "Date" -DataProperty "Temperature" -DatasetLabel "Temperature"
                        } -AutoRefresh -RefreshInterval 60 -Options @{
                            scales = @{
                                yAxes = @(
                                    @{
                                        ticks = @{
                                            min = 0
                                            max = 40
                                        }
                                    }
                                )
                            }
                        }
                    }
                    New-UDTab -Text "Last 7 Days" -Content {
                        New-UDGrid -Title "Temperature of the last 7 days" -Headers @("Date", "Temperature") -Properties @("Date", "Temperature") -Endpoint {
                            for ($i = 0; $i -le 7; $i++) {
                                $fileName = "$($((Get-Date).AddDays($i*-1)).ToString('yyyy_MM_dd')).json"
                                $fileFullPath = "$temperatureBasePath$fileName"
                                $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue
                                $obj += $content | ConvertFrom-Json
                            }
                            $obj | Out-UDGridData
                        }
                    }
                }
            }
        }

        New-UDColumn -SmallSize 12 -MediumSize 12 -LargeSize 6 -Content {
            New-UDCard -Title "Humidity" -Content {
                New-UDTabContainer -Tabs {
                    New-UDTab -Text "Today" -Content {
                        New-UDChart -Title "" -Type Line -Endpoint {
                            $fileName = "$($((Get-Date)).ToString('yyyy_MM_dd')).json"
                            $fileFullPath = "$humidityBasePath$fileName"
                            $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue
                            $obj += $content | ConvertFrom-Json
                            $obj | Select-Object Humidity,
                            @{
                                name       = 'Date';
                                expression = { [DateTime]::Parse($_.Date).ToString('HH:mm') }
                            } `
                            | Sort-Object -Property Date `
                            | Out-UDChartData -LabelProperty "Date" -DataProperty "Humidity" -DatasetLabel "Humidity"
                        } -AutoRefresh -RefreshInterval 60 -Options @{
                            scales = @{
                                yAxes = @(
                                    @{
                                        ticks = @{
                                            min = 0
                                            max = 100
                                        }
                                    }
                                )
                            }
                        }
                    }
                    New-UDTab -Text "Yesterday" -Content {
                        New-UDChart -Title "" -Type Line -Endpoint {
                            $fileName = "$($((Get-Date).AddDays(-1)).ToString('yyyy_MM_dd')).json"
                            $fileFullPath = "$humidityBasePath$fileName"
                            $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue
                            $obj += $content | ConvertFrom-Json
                            $obj | Select-Object Humidity,
                            @{
                                name       = 'Date';
                                expression = { [DateTime]::Parse($_.Date).ToString('HH:mm') }
                            } `
                            | Sort-Object -Property Date `
                            | Out-UDChartData -LabelProperty "Date" -DataProperty "Humidity" -DatasetLabel "Humidity"
                        } -AutoRefresh -RefreshInterval 60 -Options @{
                            scales = @{
                                yAxes = @(
                                    @{
                                        ticks = @{
                                            min = 0
                                            max = 100
                                        }
                                    }
                                )
                            }
                        }
                    }
                    New-UDTab -Text "Last 7 Days" -Content {
                        New-UDGrid -Title "Humidity of the last 7 days" -Headers @("Date", "Humidity") -Properties @("Date", "Humidity") -Endpoint {
                            for ($i = 0; $i -le 7; $i++) {
                                $fileName = "$($((Get-Date).AddDays($i*-1)).ToString('yyyy_MM_dd')).json"
                                $fileFullPath = "$humidityBasePath$fileName"
                                $content = Get-Content -Path $fileFullPath -ErrorAction SilentlyContinue
                                $obj += $content | ConvertFrom-Json
                            }
                            $obj | Out-UDGridData
                        }
                    }
                }
            }
        }
	}
	New-UDRow -Columns {
		New-UDColumn -Id "TemperatureMonitor"  -SmallSize 12 -MediumSize 12 -LargeSize 6 -Content {
			New-UDMonitor -Title "LiveTemperature" -Type Bar -Endpoint {
				$senseHat.Sensors.HumiditySensor.Update() | Out-Null
				([int]$senseHat.Sensors.Temperature) | Out-UDMonitorData

			}-Options @{
				scales = @{
					yAxes = @(
						@{
							ticks = @{
								min = 25
								max = 40
							}
						}
					)
				}
			}
		}
	}
}

$pages += New-UDPage -Name "ScrollpHat" -Icon bold -Content {
	New-UDColumn -SmallSize 12 -Content {
		#New-UDCard -Title "Simulate Explosion" -Content {
			New-UDInput -Title "Brightness" -Content {
				$brightnessEnum = @('Lowest','Low', 'Medium', 'High', 'Highest')
				New-UDInputField -Type 'select' -Name 'Brightness' -Placeholder 'Brightness' -Values $brightnessEnum -DefaultValue 'Lowest'
			} -Endpoint {
				param([string]$Brightness)
				Set-PhatBrightness $Brightness
			}
	}
	New-UDColumn -SmallSize 12 -Content {
		#New-UDCard -Title "Simulate Explosion" -Content {
			New-UDInput -Title "ScrollpHat"  -Content {
				New-UDInputField -Type 'textbox' -Name 'TextToDisplay' -Placeholder 'Type the text that will be displayed'
				New-UDInputField -Type 'textbox' -Name 'NumberOfIterations' -Placeholder 'Number of iterations' -DefaultValue 1
				New-UDInputField -Type 'textbox' -Name 'Speed' -Placeholder 'Number of miliseconds between each update' -DefaultValue 40
			} -Endpoint {
				param([string]$TextToDisplay, [ValidateRange(0,[int]::MaxValue)][int]$NumberOfIterations, [ValidateRange(0,[int]::MaxValue)][int]$Speed)
				Write-PhatString -Text $TextToDisplay -Iterations $NumberOfIterations -WaitMiliseconds $Speed
			}
	}
}

$pages += New-UDPage -Name "Special thanks" -Icon users -Content {
    New-UDRow -Columns {
        New-UDColumn -SmallSize 2  -Content {
            New-UDImage -height 250 -width 250 -path '/home/pi/Documents/backup/helpers/claudio.jpg'
        }
        New-UDColumn -SmallSize 2 -smalloffset 1 -Content {
            New-UDImage -height 250 -width 250 -path '/home/pi/Documents/backup/helpers/chrissy.jpg'
        }
        New-UDColumn -SmallSize 2 -smalloffset 1 -Content {
            New-UDImage -height 250 -width 250 -path '/home/pi/Documents/backup/helpers/adam.jpg'
        }
        New-UDColumn -SmallSize 2 -smalloffset 1 -Content {
            New-UDImage -height 250 -width 250 -path '/home/pi/Documents/backup/helpers/Jakub.jpg'
        }
    }
    New-UDRow -Columns {
        New-UDColumn -SmallSize 2  -Content {
            New-UDCheckbox -Label 'Cláudio Silva' -Checked
        }
        New-UDColumn -SmallSize 2  -smalloffset 1 -Content {
            New-UDCheckbox -Label 'Chrissy LeMaire' -Checked
        }
        New-UDColumn -SmallSize 2  -smalloffset 1 -Content {
            New-UDCheckbox -Label 'Adam Driscoll' -Checked
        }
        New-UDColumn -SmallSize 2  -smalloffset 1 -Content {
            New-UDCheckbox -Label 'Jakub Jareš' -Checked 
        }
    }
}

$Dashboard = New-UDDashboard -Title "My IoT Dashboard" -EndpointInitialization $ep -Pages $pages

Start-UDDashboard -Port 10001 -Dashboard $Dashboard -AutoReload