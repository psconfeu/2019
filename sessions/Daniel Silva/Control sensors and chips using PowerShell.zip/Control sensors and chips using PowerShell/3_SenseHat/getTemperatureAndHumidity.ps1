Import-Module("/home/pi/Documents/Presentation/3_SenseHat/publish/SenseHatPowerShell.dll")

$senseHat = [SenseHatPowerShell.CoreDeviceFactory]::InitAndGetIt()

if($senseHat.Sensors.HumiditySensor.Update() -eq $true){
    $temperature = [Math]::Round($senseHat.Sensors.Temperature,1)
    Invoke-RestMethod -Uri http://localhost:10000/api/temperature -Method POST -Body (@{Temperature = $temperature; Date = $(Get-Date).ToString("yyyy-MM-dd HH:mm") } | ConvertTo-Json)

    $humidity = [Math]::Round($senseHat.Sensors.Humidity,1)
    Invoke-RestMethod -Uri http://localhost:10000/api/humidity -Method POST -Body (@{Humidity = $humidity; Date = $(Get-Date).ToString("yyyy-MM-dd HH:mm") } | ConvertTo-Json)
}
