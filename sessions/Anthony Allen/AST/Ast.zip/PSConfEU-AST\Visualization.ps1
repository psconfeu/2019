$scriptBlock = {
    #requires -Version 6.0
    function Invoke-Ego {
        param()
        $speaker = "Anthony Allen"
        $result = Invoke-RestMethod -Uri http://powershell.fun
        $result |
            Where-Object { $_.Speaker -eq $speaker } |
            Format-Table -Property Name, Starts, Ends, Speaker
    }
}


# - ShowPSAst -
# Install-Module ShowPSAst -Scope CurrentUser - Works on PowerShell 7!

$scriptBlock | Show-Ast

# - EditorAstProvider -
# Install-Module EditorAstProvider -Scope CurrentUser
New-EditorAstPSDrive
pushd CurrentFile:\
popd

# - PSGraphPlus -
# Install-Module PSGraphPlus -Scope CurrentUser
$scriptBlock | Show-AstGraph -Annotate

#region Parsing

# Two ways to get to the AST programaically. Through the AST property of a script block:

$scriptBlock.Ast

# Using the parser:
$tokens = $null
$errors = $null
$Ast = [System.Management.Automation.Language.Parser]::ParseFile(".\DummyScript.ps1", [ref]$tokens, [ref]$errors)

$rawText = Get-Content .\DummyScript.ps1 -Raw
$tokens = $null
$errors = $null
$Ast = [System.Management.Automation.Language.Parser]::ParseInput($rawText, [ref]$tokens, [ref]$errors)


# Every Ast object has the methods Find and Findall. The methods take two arguments, a predicate which has the input of an Ast object,
#  and a boolean which specifies whether to search in nested script blocks.

$functions = $scriptBlock.Ast.FindAll(
    {
        param([System.Management.Automation.Language.Ast]$ast)
        $ast -is [System.Management.Automation.Language.FunctionDefinitionAst]
    }, $false
)

#endregion Parsing

