using namespace Microsoft.PowerShell.EditorServices.Extensions
using namespace System.Management.Automation.Language
function ConvertTo-ForeachLoop {
    [CmdletBinding()]
    [EditorCommand(DisplayName='Convert Foreach-Object to foreach loop')]
    param(
        [Ast]
        $Ast = (Find-Ast -AtCursor)
    )

    end {
        function _getFirstDollarUnder {
            param([string]$Text)
            $parsed = [Parser]::ParseInput($Text, [ref]$null, [ref]$null)
            $nextDollarUnder = $parsed.Find(
                {
                    param([Ast]$Ast)
                    $Ast -is [VariableExpressionAst] -and
                    ($Ast.VariablePath.UserPath -eq "_" -or
                        $Ast.VariablePath.UserPath -eq "PSItem")
                }, $false
            )
            if ($nextDollarUnder) {
                $nextDollarUnder.Extent
            }

        }
        # Find the Foreach-Object CommandAst
        $foreachCommandAst = $Ast | Find-Ast -Ancestor -First -FilterScript {
            $_.CommandElements.Value -eq "Foreach-Object" -or
            $ExecutionContext.InvokeCommand.GetCommand($($_.CommandElements.Value), 'Alias').Definition -eq "Foreach-Object"
        }
        $foreachCommandScriptBlock = $foreachCommandAst | Find-Ast -First -FilterScript { $_ -is [ScriptBlockAst] }

        $foreachExtentText = "foreach (`$item in `$items) $($foreachCommandScriptBlock.Extent.Text)"

        # We replace each occurence of $_ or $PSItem with $item, but only in the foreach scope.
        while ($nextDollarUnder = _getFirstDollarUnder $foreachExtentText) {
            $foreachExtentText = $foreachExtentText.
              Remove($nextDollarUnder.StartOffset,$($nextDollarUnder.EndOffset - $nextDollarUnder.StartOffset)).
              Insert($nextDollarUnder.StartOffset, '$item')
        }

        # The pipeline before the foreach-command needs to be assigned to the $items variable

        $pipeLine = $foreachCommandAst | Find-Ast -Ancestor -First -FilterScript {$_ -is [PipelineAst]}
        $convertToScriptExtentSplat = @{
            StartLineNumber = $pipeLine.PipelineElements[0].Extent.StartLineNumber
            StartColumnNumber = $pipeLine.PipelineElements[0].Extent.StartColumnNumber
            EndLineNumber = $pipeLine.PipelineElements[-2].Extent.EndLineNumber
            EndColumnNumber = $pipeLine.PipelineElements[-2].Extent.EndColumnNumber
        }
        $pipeLineCommandsExtent = ConvertTo-ScriptExtent @convertToScriptExtentSplat
        $itemsExtent = "`$items = " + $pipeLineCommandsExtent.Text + [environment]::NewLine

        # Now we need to replace the entire pipelineast with the newly created foreach loop

        $pipeLine.Extent | Set-ScriptExtent -Text $foreachExtentText

        $itemsTarget = ConvertTo-ScriptExtent -Line $pipeLine.Extent.StartLineNumber
        $itemsTarget | Set-ScriptExtent -Text $itemsExtent

    }
}

Export-ModuleMember -Function ConvertTo-ForeachLoop