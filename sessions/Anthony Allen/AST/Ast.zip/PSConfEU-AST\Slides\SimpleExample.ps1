$sb ={if ($true) {
    Write-Output "PSConfEU is Awesome!"
}}



