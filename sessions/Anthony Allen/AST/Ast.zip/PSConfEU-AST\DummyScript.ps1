#requires -Version 6.0
function Invoke-Ego {
    param()
    $speaker = "Anthony Allen"
    $result = Invoke-RestMethod -Uri http://powershell.fun
    $result |
        Where-Object {$_.Speaker -eq $speaker} |
        Format-Table -Property Name, Starts, Ends, Speaker
}