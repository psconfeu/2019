﻿#region get custom endpoints
$endpoints = Invoke-Command -ComputerName PSCONF04 -ScriptBlock { Get-PSSessionConfiguration | where Name -notlike "microsoft.*" }
$endpoints | Format-Table Name, RunAsUser, RunAsVirtualAccount
#endregion

#region analyse session configuration for a particular endpoint
$restricted = $endpoints.Where({$_.Name -eq "JEARestricted"}) | Select-Object -First 1

$config = $restricted.ConfigFilePath

(Split-Path $config -Leaf).TrimEnd("\.pssc") -split "_"

Start-Process notepad.exe -ArgumentList "\\psconf04\c$\temp\JEARestricted.pssc"

$running_hash = (Invoke-Command -ComputerName PSCONF04 -ScriptBlock { Get-FileHash $args[0] } -ArgumentList $config).Hash
$shouldbe_hash = (Get-FileHash "\\psconf04\c$\temp\JEARestricted.pssc").Hash
if ($running_hash -eq $shouldbe_hash) { 
    Write-Host "Compliant!" -ForegroundColor Green
} else {
    Write-Host "Noncompliant!" -ForegroundColor Red
}
#endregion

#region analyse roles
$sb = {
    $paths = $env:PSModulePath -split ";"
    $rcfiles = foreach ($path in $paths) {
        Get-ChildItem -Path $path -Filter "$($args[0]).psrc" -Recurse
    }
    if ($rcfiles.Count -eq 1) {
    
    } elseif ($rcfiles.Count -eq 0) {
        Write-Warning "No RC file found for $($args[0])"
    } else {
        Write-Warning "Multiple RC files found for $($args[0])"
    }
}
foreach ($role in $restricted.RoleDefinitions.GetEnumerator()) {
    foreach ($item in $role.Value.GetEnumerator()) {
        $name = $item.Value
        Invoke-Command -ComputerName PSCONF04 -ScriptBlock $sb -ArgumentList $name
    }
}
#endregion