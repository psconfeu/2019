﻿$manifest = @{
    ModuleVersion = '0.0.0.2'
    Author = 'Evgenij Smirnov'
    CompanyName = 'metaBPA.org'
    Copyright = '(c) 2019 metaBPA.org'
    Description = 'This JEA Workstation module contains some helper functions to help facilitate transition to JEA from the admin viewpoint.'
	HelpInfoURI = 'https://github.com/metabpa/jeacockpit'
    PowerShellVersion = '3.0'
    Path = "$PSScriptRoot\JEAWorkstation\JEAWorkstation.psd1"
    RootModule = 'JEAWorkstation.psm1'
    NestedModules = @()
    FunctionsToExport = @(
        'Find-RemotingCode'
        'Set-DefaultEndpoint'
        'Find-MissingCommands'
        'Connect-RemotingSession'
    )
    VariablesToExport = @()
    PrivateData = @{
        'MetaBPARegKey' = 'metaBPA.org'
        'ModuleRegKey' = 'JEACockpit'
    }
}
New-ModuleManifest @manifest