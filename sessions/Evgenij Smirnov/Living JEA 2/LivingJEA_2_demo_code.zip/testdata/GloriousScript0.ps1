﻿Invoke-Command -ComputerName PSCONF01 -ScriptBlock {Restart-Service spooler}
Enter-PSSession PSCONF01
Get-Service
Do-Something