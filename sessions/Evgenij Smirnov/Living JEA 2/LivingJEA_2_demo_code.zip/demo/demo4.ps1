﻿Import-Module "C:\PSConfEU\module\JEAWorkstation\JEAWorkstation.psd1" -Force

#region do jobs help against winrm restarts?
Enter-PSSession -ComputerName PSCONF03

Start-Job -Name "my_first_job" -ScriptBlock { $sum = 0; (1..10000).ForEach({$sum += Get-Random}); $sum }

Restart-Service WinRM

Get-Job -Name "my_first_job"

Receive-Job -Name "my_first_job"

Get-Job | Remove-Job
#endregion

#region session renewal
$sess = New-PSSession -ComputerName PSCONF03

$sess

Invoke-Command -ComputerName PSCONF03 -ScriptBlock { Restart-Service WinRM }

$sess

$sess = Connect-RemotingSession -Session $sess

$sess
#endregion