﻿#region trap missing command
    trap [System.Management.Automation.CommandNotFoundException]{
        $missing_command = $_.Exception.ErrorRecord.TargetObject
        $script_name = $MyInvocation.InvocationName
        $missing_command | Add-Content c:\temp\missingcommands.txt
        $res = Invoke-RestMethod -UseBasicParsing -Method Get -UseDefaultCredentials -Uri "http://devws/Feedback/MissingCommand?missingcommand=$missing_command&invokingmachine=$($env:COMPUTERNAME)&invokinguser=$($env:USERNAME)"
        $res | Add-Content c:\temp\httpresponse.txt
        Write-Warning "Command '$missing_command' is missing on $($env:COMPUTERNAME)"
        continue
    }
#endregion
$processes = Get-Process
Write-Host "$($processes.Count) processes are running"
Start-Process notepad.exe