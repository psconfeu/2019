﻿#region working with RunAsAccounts
Start-Process "\\psconf04\c$\temp"

#region Virtual Account
Enter-PSSession PSCONF04 -ConfigurationName JEAVirtual
$env:USERNAME
$env:USERPROFILE
Test-Connection "10.0.101.254" -Count 1 -Quiet
Get-ChildItem "\\DEVDC01\Share"
Get-ChildItem "\\DEVDC01\Share2"
Invoke-Command {Get-ADUser -Filter *} -ComputerName DEVDC01
Exit-PSSession
#endregion

#region Passthru user
Enter-PSSession PSCONF04 -ConfigurationName JEAPassthru
$env:USERNAME
$env:USERPROFILE
Test-Connection "10.0.101.254" -Count 1 -Quiet
Get-ChildItem "\\DEVDC01\Share"
Get-ChildItem "\\DEVDC01\Share2"
Invoke-Command {Get-ADUser -Filter *} -ComputerName DEVDC01
Exit-PSSession
#endregion

#region Explicit creds
Enter-PSSession PSCONF04 -ConfigurationName JEAExplicit
$env:USERNAME
$env:USERPROFILE
Test-Connection "10.0.101.254" -Count 1 -Quiet
Get-ChildItem "\\DEVDC01\Share"
Get-ChildItem "\\DEVDC01\Share2"
Invoke-Command {Get-ADUser -Filter *} -ComputerName DEVDC01
Exit-PSSession
#endregion

#region interactive session to a restricted endpoint
Enter-PSSession PSCONF04 -ConfigurationName JEARestricted
#endregion

#region remote invocation against restricted endpoint
$sess = New-PSSession -ComputerName PSCONF04 -ConfigurationName JEARestricted
Invoke-Command -Session $sess -ScriptBlock { $env:USERNAME | Set-Content "c:\temp\lastuser.txt" }
Start-Process notepad.exe -ArgumentList "\\psconf04\c$\temp\lastuser.txt"

Import-PSSession -Session $sess -Prefix "PSCONF04"
Get-Command *PSCONF04* -All
Remove-PSSession $sess.Id
#endregion

#region remote invocation with ephemeral session
Invoke-Command -ComputerName PSCONF04 -ConfigurationName JEARestricted -ScriptBlock { Restart-Service spooler }
#endregion

#endregion