﻿Import-Module "C:\PSConfEU\module\JEAWorkstation\JEAWorkstation.psd1" -Force

#region remoting code
Find-RemotingCode -Path "C:\PSConfEU\testdata\GloriousScript0.ps1"
#endregion

#region default endpoints
Set-DefaultEndpoint -ConfigurationName "JEAVirtual" -Verbose

Enter-PSSession DEVDC01

Enter-PSSession PSCONF04

Exit-PSSession
#endregion