﻿$demo_layout = [ordered]@{
    'DEMO1' = @("C:\PSConfEU\demo\demo1.ps1","C:\PSConfEU\module\JEAWorkstation\JEAWorkstation.psm1")
    'DEMO2' = @("C:\PSConfEU\demo\demo2.ps1","C:\PSConfEU\module\JEAWorkstation\JEAWorkstation.psm1","C:\PSConfEU\demo\remote_execution.ps1")
    'DEMO3' = @("C:\PSConfEU\demo\demo3.ps1")
    'DEMO4' = @("C:\PSConfEU\demo\demo4.ps1")
}
if ($psise.CurrentVisibleVerticalTool.IsVisible) {
    $psise.CurrentVisibleVerticalTool.IsVisible = $false
}
$current_tab = $psise.CurrentPowerShellTab
$current_tab.DisplayName = "Start-Demo"
foreach ($demo in $demo_layout.GetEnumerator()) {
    $demo_tab = $psise.PowerShellTabs.Add()
    $demo_tab.DisplayName = $demo.Name    foreach ($file in $demo.Value) {
        $demo_file = $demo_tab.Files.Add($file)
        $demo_file.Editor.EnsureVisible(1)
        $demo_file.Editor.Focus()
        $demo_file.Editor.ToggleOutliningExpansion()
    }
}
Start-Process "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe" -ArgumentList "http://devws/Home/Index"
$psise.PowerShellTabs.SetSelectedPowerShellTab($current_tab)