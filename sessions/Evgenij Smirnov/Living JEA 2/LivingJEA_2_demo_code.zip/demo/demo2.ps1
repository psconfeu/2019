﻿Import-Module "C:\PSConfEU\module\JEAWorkstation\JEAWorkstation.psd1" -Force

#region check for missing commands
#region introduction
#region PS5.1 on default endpoint
$commands = Invoke-Command { (Get-Command -All).Name } -ComputerName PSCONF04
$commands.Count
#endregion

#region PS5.1 on restricted endpoint
$commands = Invoke-Command { (Get-Command -All).Name } -ComputerName PSCONF04 -ConfigurationName JEARestricted
$commands.Count
#endregion

#region PS2 on default endpoint
$commands = Invoke-Command { (Get-Command -All).Name } -ComputerName PSCONF01
$commands.Count
#endregion

#region this is more like it...
$commands = Invoke-Command { Get-Command | Select-Object -ExpandProperty Name } -ComputerName PSCONF01
$commands.Count
#endregion
#endregion

#region check
Find-MissingCommands -Path "C:\PSConfEU\testdata" -ComputerName PSCONF03
Find-MissingCommands -Path "C:\PSConfEU\testdata" -ComputerName PSCONF04 -ConfigurationName JEARestricted
#endregion
#endregion
exit

#region catch missing commands
#region simple try/catch
try {
    Get-SomethingDone
} catch [System.Management.Automation.CommandNotFoundException] {
    Write-Warning "Command '$($_.Exception.ErrorRecord.TargetObject)' not found"
}
#endregion

#region remote script invocation
Remove-Item "\\psconf04\c$\temp\missingcommands.txt" -Force
Remove-Item "\\psconf04\c$\temp\httpresponse.txt" -Force

Invoke-Command -ComputerName PSCONF04 -FilePath C:\PSConfEU\demo\remote_execution.ps1
Invoke-Command -ComputerName PSCONF04 -FilePath C:\PSConfEU\demo\remote_execution.ps1 -ConfigurationName JEARestricted

if (Test-Path "\\psconf04\c$\temp\missingcommands.txt") { Get-Content "\\psconf04\c$\temp\missingcommands.txt" }
if (Test-Path "\\psconf04\c$\temp\httpresponse.txt") { Get-Content "\\psconf04\c$\temp\httpresponse.txt" }
#endregion
#endregion