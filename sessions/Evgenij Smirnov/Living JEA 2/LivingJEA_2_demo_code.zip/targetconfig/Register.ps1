﻿Register-PSSessionConfiguration -Name JEAVirtual -Path C:\temp\JEAVirtual.pssc
Register-PSSessionConfiguration -Name JEAPassthru -Path C:\temp\JEAPassthru.pssc
Register-PSSessionConfiguration -Name JEAExplicit -Path C:\temp\JEAPassthru.pssc -RunAsCredential (Get-Credential "ESMOBILE\jeamaster")
pssc
Register-PSSessionConfiguration -Name JEARestricted -Path C:\temp\JEARestricted.pssc -RunAsCredential (Get-Credential "ESMOBILE\jeamaster")