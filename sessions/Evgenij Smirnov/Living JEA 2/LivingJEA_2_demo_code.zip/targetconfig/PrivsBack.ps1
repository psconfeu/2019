﻿sc.exe privs WinRM SeAssignPrimaryTokenPrivilege/SeAuditPrivilege/SeChangeNotifyPrivilege/SeCreateGlobalPrivilege/SeImpersonatePrivilege/SeTcbPrivilege
# or directly setting the value in the registry
$HT = @{
 Path = 'HKLM:\SYSTEM\CurrentControlSet\Services\WinRM'
 Name = 'RequiredPrivileges'
 Value = @(
  'SeAssignPrimaryTokenPrivilege',
  'SeAuditPrivilege',
  'SeChangeNotifyPrivilege',
  'SeCreateGlobalPrivilege',
  'SeImpersonatePrivilege',
  'SeTcbPrivilege'
 )
}
Set-ItemProperty -Type MultiString @HT -Force
 
# Restore the local system account
Get-CimInstance -ClassName Win32_Service -Filter "Name='WinRM'"| 
Invoke-CimMethod -MethodName Change -Arguments @{StartName='LocalSystem'}
 
# Apply changes
Restart-Service -Name WinRM
