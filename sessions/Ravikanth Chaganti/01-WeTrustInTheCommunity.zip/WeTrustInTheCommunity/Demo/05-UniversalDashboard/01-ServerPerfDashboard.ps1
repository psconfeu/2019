# Start the perf dashboard
Start-Process 'http://localhost:10000'