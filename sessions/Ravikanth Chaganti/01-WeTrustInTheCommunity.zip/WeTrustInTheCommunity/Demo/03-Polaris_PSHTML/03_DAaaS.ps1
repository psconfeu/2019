Push-Location
Set-Location -Path C:\Documents\GitHub\S2DAutomation
.\daaasUI.ps1
Pop-Location