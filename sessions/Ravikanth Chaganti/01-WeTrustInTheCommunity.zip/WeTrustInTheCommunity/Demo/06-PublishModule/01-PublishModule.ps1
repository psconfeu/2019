$apiKey = 'oy2emcbbfcqqpetwhwjavsin666if4wuzl5adiuhimugee'

Get-Module -ListAvailable -Name PSWindowsAdminCenter
Get-Command -Module PSWindowsAdminCenter

Publish-Module -Name PSWindowsAdminCenter -NuGetApiKey $apiKey