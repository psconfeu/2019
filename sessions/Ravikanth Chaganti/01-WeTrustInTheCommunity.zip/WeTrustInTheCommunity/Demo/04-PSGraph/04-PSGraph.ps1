Push-Location
Set-Location .\Demo\04-PSGraph

. .\getdscconfigdepends.ps1
.\editorCommands.ps1