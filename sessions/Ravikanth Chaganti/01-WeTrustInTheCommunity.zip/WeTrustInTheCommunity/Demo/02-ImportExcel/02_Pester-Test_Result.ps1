Push-Location
Set-Location -Path .\Demo\02-ImportExcel
Invoke-Item -Path .\R730XD-PostCluster.xlsx
Pop-Location