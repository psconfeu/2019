﻿New-Item -ItemType SymbolicLink -Path 'C:\pwsh\6\profile.ps1' -Value 'C:\Windows\System32\WindowsPowerShell\v1.0\profile.ps1'
